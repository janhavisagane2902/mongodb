from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27071")
    db=client["office"]
    coll=db["workers"]

    for doc in coll.find():
        print(doc)

except:
    print("Error....")