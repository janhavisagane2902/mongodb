from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:270721")
    db=["office"]
    coll=db["workers"]

    dept=input("Enter Department: ")
    qr={}
    qr["dept"]=dept
    

    for doc in coll.find_one(qr):
        print(doc)

except:
    print("Error....")