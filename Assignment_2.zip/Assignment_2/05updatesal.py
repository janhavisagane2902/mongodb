from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27071")
    db=client["office"]
    coll=db["workers"]

    qr={}
    empid=int(input("Enter Employee Id: "))
    qr["_id"]=empid

    chval={}
    sal=int(input("Enter new salary: "))
    chval["salary"]=sal

    upd={"$set":chval}

    coll.update_one(qr,upd)
    
    for doc in coll.find(qr):
        print(doc)

    print("Employee updated successfully...")

except:
    print("Error...")