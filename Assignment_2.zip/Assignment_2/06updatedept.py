from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27071")
    db=client["office"]
    coll=db["workers"]

    qr={}
    id=int(input("Enter Id: "))
    qr["_id"]=id

    upval={}
    colnm1=input("Enter new city: ")
    colnm2=input("Enter new department: ")

    upval["city"]=colnm1
    upval["dept"]=colnm2

    upd={"$set":upval}

    coll.update_one(qr,upd)
    print("city and department updated successfully...")

except:
    print("Error...")