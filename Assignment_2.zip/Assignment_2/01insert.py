from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]

    dic={}
    id=int(input("Entet Id: "))
    empnm=input("Enter name: ")
    dept=input("Enter Department: ")
    post=input("Enter Post: ")
    city=input("Enter City: ")
    salary=int(input("Enter Salary: "))
    mobno=int(input("Enter Mobile Number: "))
    email=input("Enter emailId: ")

    dic["_id"]=id
    dic["empnm"]=empnm
    dic["dept"]=dept
    dic["post"]=post
    dic["city"]=city
    dic["salary"]=salary
    dic["mobno"]=mobno
    dic["email"]=email

    coll.insert_one(dic)
    print("Details of New Employee added successfully..")

except:
    print("Invail input.....")